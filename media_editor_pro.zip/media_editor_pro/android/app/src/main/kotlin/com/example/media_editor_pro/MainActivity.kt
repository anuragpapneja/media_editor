package com.example.media_editor_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
