import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pro_image_editor/pro_image_editor.dart';
import 'package:video_player/video_player.dart';

class EditorScreen extends StatefulWidget {
  final String mediaPath;
  final bool isVideo;

  const EditorScreen({
    super.key,
    required this.mediaPath,
    required this.isVideo,
  });

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  VideoPlayerController? _videoPlayerController;
  ProVideoController? _proVideoController;
  bool _isInit = false;

  @override
  void initState() {
    super.initState();
    if (widget.isVideo) {
      _initVideo();
    } else {
      setState(() {
        _isInit = true;
      });
    }
  }

  Future<void> _initVideo() async {
    final file = File(widget.mediaPath);
    _videoPlayerController = VideoPlayerController.file(file);
    await _videoPlayerController!.initialize();

    _proVideoController = ProVideoController(
      videoPlayer: VideoPlayer(_videoPlayerController!),
      videoDuration: _videoPlayerController!.value.duration,
      initialResolution: _videoPlayerController!.value.size,
      fileSize: await file.length(),
    );

    if (mounted) {
      setState(() {
        _isInit = true;
      });
    }
  }

  @override
  void dispose() {
    _videoPlayerController?.dispose();
    _proVideoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInit) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (widget.isVideo) {
      return _buildVideoEditor();
    } else {
      return _buildImageEditor();
    }
  }

  Widget _buildImageEditor() {
    return ProImageEditor.file(
      File(widget.mediaPath),
      callbacks: ProImageEditorCallbacks(
        onImageEditingComplete: (Uint8List bytes) async {
          Navigator.pop(context);
        },
      ),
      configs: const ProImageEditorConfigs(
        designMode: ImageEditorDesignMode.material,
        mainEditor: MainEditorConfigs(
          tools: [
            SubEditorMode.paint,
            SubEditorMode.text,
            SubEditorMode.cropRotate,
            SubEditorMode.filter,
            SubEditorMode.blur,
            SubEditorMode.emoji,
            SubEditorMode.sticker,
          ],
        ),
      ),
    );
  }

  Widget _buildVideoEditor() {
    return ProImageEditor.video(
      _proVideoController!,
      callbacks: ProImageEditorCallbacks(
        onImageEditingComplete: (Uint8List bytes) async {
          Navigator.pop(context);
        },
      ),
      configs: const ProImageEditorConfigs(
        designMode: ImageEditorDesignMode.material,
        mainEditor: MainEditorConfigs(
          tools: [
            SubEditorMode.paint,
            SubEditorMode.text,
            SubEditorMode.cropRotate,
            SubEditorMode.filter,
            SubEditorMode.blur,
            SubEditorMode.emoji,
            SubEditorMode.sticker,
          ],
        ),
      ),
    );
  }
}
