import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/foundation.dart';
import '../services/face_filter_service.dart';
import 'editor_screen.dart';
import 'dart:io';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _controller;
  List<CameraDescription>? _cameras;
  int _selectedCameraIndex = 0;
  final FaceFilterService _faceFilterService = FaceFilterService();
  List<Face> _detectedFaces = [];
  bool _isProcessingFrames = false;
  bool _isRecording = false;
  bool _showFilters = false;
  FlashMode _flashMode = FlashMode.off;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    _cameras = await availableCameras();
    if (_cameras != null && _cameras!.isNotEmpty) {
      _startCamera(_selectedCameraIndex);
    }
  }

  Future<void> _startCamera(int index) async {
    if (_controller != null) {
      await _controller!.dispose();
    }

    _controller = CameraController(
      _cameras![index],
      ResolutionPreset.high,
      enableAudio: true,
      imageFormatGroup: ImageFormatGroup.yuv420,
    );

    try {
      await _controller!.initialize();
      await _controller!.setFlashMode(_flashMode);
      
      if (!mounted) return;

      setState(() {});

      _controller!.startImageStream((image) async {
        if (!_showFilters || _isProcessingFrames) return;
        _isProcessingFrames = true;

        final inputImage = _faceFilterService.inputImageFromCameraImage(
          image,
          _cameras![index],
        );

        if (inputImage != null) {
          final faces = await _faceFilterService.detectFaces(inputImage);
          if (faces.isNotEmpty) {
            debugPrint('Detected ${faces.length} faces');
          }
          if (mounted) {
            setState(() {
              _detectedFaces = faces;
            });
          }
        }
        _isProcessingFrames = false;
      });
    } catch (e) {
      debugPrint('Error initializing camera: $e');
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    _faceFilterService.dispose();
    super.dispose();
  }

  Future<void> _takePicture() async {
    if (_controller == null || !_controller!.value.isInitialized) return;
    try {
      final XFile image = await _controller!.takePicture();
      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => EditorScreen(
              mediaPath: image.path,
              isVideo: false,
            ),
          ),
        );
      }
    } catch (e) {
      debugPrint('Error taking picture: $e');
    }
  }

  Future<void> _toggleRecording() async {
    if (_controller == null || !_controller!.value.isInitialized) return;

    if (_isRecording) {
      try {
        final XFile video = await _controller!.stopVideoRecording();
        setState(() => _isRecording = false);
        if (mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => EditorScreen(
                mediaPath: video.path,
                isVideo: true,
              ),
            ),
          );
        }
      } catch (e) {
        debugPrint('Error stopping video recording: $e');
      }
    } else {
      try {
        await _controller!.startVideoRecording();
        setState(() => _isRecording = true);
      } catch (e) {
        debugPrint('Error starting video recording: $e');
      }
    }
  }

  Future<void> _switchCamera() async {
    if (_cameras == null || _cameras!.isEmpty) return;
    _selectedCameraIndex = (_selectedCameraIndex + 1) % _cameras!.length;
    await _startCamera(_selectedCameraIndex);
  }

  Future<void> _toggleFlash() async {
    if (_controller == null || !_controller!.value.isInitialized) return;
    
    FlashMode nextMode;
    switch (_flashMode) {
      case FlashMode.off:
        nextMode = FlashMode.always;
        break;
      case FlashMode.always:
        nextMode = FlashMode.auto;
        break;
      case FlashMode.auto:
        nextMode = FlashMode.off;
        break;
      default:
        nextMode = FlashMode.off;
    }

    try {
      await _controller!.setFlashMode(nextMode);
      setState(() {
        _flashMode = nextMode;
      });
    } catch (e) {
      debugPrint('Error setting flash mode: $e');
    }
  }

  Future<void> _pickFromGallery() async {
    final XFile? media = await _picker.pickMedia();
    if (media != null) {
      final bool isVideo = media.path.toLowerCase().endsWith('.mp4') || 
                         media.path.toLowerCase().endsWith('.mov') ||
                         media.path.toLowerCase().endsWith('.avi');
      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => EditorScreen(
              mediaPath: media.path,
              isVideo: isVideo,
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_controller == null || !_controller!.value.isInitialized) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          CameraPreview(_controller!),
          if (_showFilters) _buildFaceOverlay(),
          _buildControls(),
        ],
      ),
    );
  }

  Widget _buildFaceOverlay() {
    return CustomPaint(
      painter: FacePainter(
        faces: _detectedFaces,
        previewSize: _controller!.value.previewSize!,
        orientation: _controller!.value.deviceOrientation,
        lensDirection: _cameras![_selectedCameraIndex].lensDirection,
      ),
    );
  }

  IconData _getFlashIcon() {
    switch (_flashMode) {
      case FlashMode.off:
        return Icons.flash_off;
      case FlashMode.always:
        return Icons.flash_on;
      case FlashMode.auto:
        return Icons.flash_auto;
      default:
        return Icons.flash_off;
    }
  }

  Widget _buildControls() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: Icon(_getFlashIcon(), color: Colors.white),
                  onPressed: _toggleFlash,
                ),
                IconButton(
                  icon: const Icon(Icons.flip_camera_ios, color: Colors.white),
                  onPressed: _switchCamera,
                ),
              ],
            ),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: const Icon(Icons.photo_library, color: Colors.white, size: 32),
                  onPressed: _pickFromGallery,
                ),
                GestureDetector(
                  onLongPress: _toggleRecording,
                  onLongPressUp: _toggleRecording,
                  onTap: _takePicture,
                  child: Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 4),
                    ),
                    child: Center(
                      child: Container(
                        height: 60,
                        width: 60,
                        decoration: BoxDecoration(
                          color: _isRecording ? Colors.red : Colors.white,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(
                    Icons.face, 
                    color: _showFilters ? Colors.yellow : Colors.white, 
                    size: 32
                  ),
                  onPressed: () {
                    setState(() {
                      _showFilters = !_showFilters;
                      if (!_showFilters) {
                        _detectedFaces = [];
                      }
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text(
              'Tap for photo, Hold for video',
              style: TextStyle(color: Colors.white, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

class FacePainter extends CustomPainter {
  final List<Face> faces;
  final Size previewSize;
  final DeviceOrientation orientation;
  final CameraLensDirection lensDirection;

  FacePainter({
    required this.faces,
    required this.previewSize,
    required this.orientation,
    required this.lensDirection,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (faces.isEmpty) return;

    for (final face in faces) {
      // Scale coordinates from preview size to widget size
      final double sensorWidth = previewSize.height;
      final double sensorHeight = previewSize.width;

      final double scaleX = size.width / sensorWidth;
      final double scaleY = size.height / sensorHeight;

      // Handle mirroring for front camera
      double left;
      double right;
      if (lensDirection == CameraLensDirection.front) {
        left = size.width - (face.boundingBox.right * scaleX);
        right = size.width - (face.boundingBox.left * scaleX);
      } else {
        left = face.boundingBox.left * scaleX;
        right = face.boundingBox.right * scaleX;
      }

      double top = face.boundingBox.top * scaleY;
      double bottom = face.boundingBox.bottom * scaleY;

      final Rect rect = Rect.fromLTRB(left, top, right, bottom);

      // Draw specs/glasses
      _drawSpecs(canvas, rect);
    }
  }

  void _drawSpecs(Canvas canvas, Rect faceRect) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0
      ..color = Colors.black;

    final fillPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.white.withOpacity(0.3);

    // Calculate positions
    final centerY = faceRect.center.dy - faceRect.height * 0.1;
    final leftEyeX = faceRect.center.dx - faceRect.width * 0.15;
    final rightEyeX = faceRect.center.dx + faceRect.width * 0.15;
    final lensRadius = faceRect.width * 0.12;

    // Draw left lens
    canvas.drawCircle(Offset(leftEyeX, centerY), lensRadius, fillPaint);
    canvas.drawCircle(Offset(leftEyeX, centerY), lensRadius, paint);

    // Draw right lens
    canvas.drawCircle(Offset(rightEyeX, centerY), lensRadius, fillPaint);
    canvas.drawCircle(Offset(rightEyeX, centerY), lensRadius, paint);

    // Draw bridge (connecting the lenses)
    final bridgePath = Path()
      ..moveTo(leftEyeX + lensRadius, centerY)
      ..lineTo(rightEyeX - lensRadius, centerY);
    canvas.drawPath(bridgePath, paint);

    // Draw left temple (arm)
    final leftTemplePath = Path()
      ..moveTo(leftEyeX - lensRadius, centerY)
      ..lineTo(faceRect.left - 5, centerY);
    canvas.drawPath(leftTemplePath, paint);

    // Draw right temple (arm)
    final rightTemplePath = Path()
      ..moveTo(rightEyeX + lensRadius, centerY)
      ..lineTo(faceRect.right + 5, centerY);
    canvas.drawPath(rightTemplePath, paint);
  }

  @override
  bool shouldRepaint(FacePainter oldDelegate) => true;
}