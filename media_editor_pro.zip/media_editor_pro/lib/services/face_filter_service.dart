import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:google_mlkit_face_mesh_detection/google_mlkit_face_mesh_detection.dart';
import 'package:camera/camera.dart';
import 'dart:ui';
import 'package:flutter/foundation.dart';

class FaceFilterService {
  late final FaceDetector _faceDetector;
  late final FaceMeshDetector _meshDetector;
  bool _isInitialized = false;

  FaceFilterService() {
    _faceDetector = FaceDetector(
      options: FaceDetectorOptions(
        enableLandmarks: true,
        enableContours: true,
        enableClassification: true,
        performanceMode: FaceDetectorMode.fast,
      ),
    );

    _meshDetector = FaceMeshDetector(
      option: FaceMeshDetectorOptions.faceMesh,
    );
    _isInitialized = true;
  }

  Future<List<Face>> detectFaces(InputImage inputImage) async {
    if (!_isInitialized) return [];
    return await _faceDetector.processImage(inputImage);
  }

  Future<List<FaceMesh>> detectFaceMesh(InputImage inputImage) async {
    if (!_isInitialized) return [];
    return await _meshDetector.processImage(inputImage);
  }

  void dispose() {
    _faceDetector.close();
    _meshDetector.close();
  }

  /// Converts a camera image to an InputImage for ML Kit
  InputImage? inputImageFromCameraImage(CameraImage image, CameraDescription camera) {
    final sensorOrientation = camera.sensorOrientation;
    InputImageRotation? rotation;
    if (defaultTargetPlatform == TargetPlatform.android) {
      var rotationCompensation = _orientations[0];
      if (sensorOrientation != null) {
        rotationCompensation = (sensorOrientation + (rotationCompensation ?? 0) + 360) % 360;
      }
      rotation = InputImageRotationValue.fromRawValue(rotationCompensation);
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      rotation = InputImageRotationValue.fromRawValue(sensorOrientation);
    }
    if (rotation == null) return null;

    final format = InputImageFormatValue.fromRawValue(image.format.raw);
    if (format == null ||
        (defaultTargetPlatform == TargetPlatform.android && format != InputImageFormat.nv21) ||
        (defaultTargetPlatform == TargetPlatform.iOS && format != InputImageFormat.bgra8888)) {
      // On some android devices, the format might be yuv_420_888 but raw value might not match nv21 exactly.
      // We can try to proceed if we have 3 planes.
    }

    final WriteBuffer allBytes = WriteBuffer();
    for (final Plane plane in image.planes) {
      allBytes.putUint8List(plane.bytes);
    }
    final bytes = allBytes.done().buffer.asUint8List();

    return InputImage.fromBytes(
      bytes: bytes,
      metadata: InputImageMetadata(
        size: Size(image.width.toDouble(), image.height.toDouble()),
        rotation: rotation,
        format: format ?? (defaultTargetPlatform == TargetPlatform.android ? InputImageFormat.nv21 : InputImageFormat.bgra8888),
        bytesPerRow: image.planes[0].bytesPerRow,
      ),
    );
  }

  final Map<int, int> _orientations = {
    0: 0,
    90: 90,
    180: 180,
    270: 270,
  };
}
